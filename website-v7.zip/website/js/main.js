/**
 * main.js — PK Tech Services client-side enhancements
 *
 * Milestone 15 · JavaScript & Progressive Enhancement
 *
 * Vanilla ES6+, no dependencies, no globals. Everything is progressive
 * enhancement: every page is readable and navigable without JavaScript, and
 * this file only adds behaviour on top of the existing markup (Phase 6 §8).
 *
 * Features (this milestone):
 *   1. Active navigation  — derives aria-current="page" from the URL, never
 *      hardcodes the current page.
 *   2. Mobile navigation  — hamburger toggle, close on link/Escape, focus
 *      trap while open, focus restored on close, scroll lock, aria-expanded.
 *   3. Smooth scrolling   — same-page anchor links only; respects
 *      prefers-reduced-motion and offsets the sticky header.
 *   4. Header state       — .is-scrolled shadow once the page scrolls
 *      (state class applied by JS, styled by CSS, Phase 6 §11).
   *   5. Form enhancement   — inline validation for the documented field set
   *      (Phase 3 §6.7/§6.8 copy), aria-invalid + live-region messages,
   *      submission blocked only while the action is the FORMSPREE_ENDPOINT
   *      placeholder; once wired, valid forms submit natively (no AJAX).
   *   6. Product carousel   — lightweight manual image carousel (products
   *      page): swipe/drag and keyboard-driven, dots + arrows, no autoplay.
 *
 * No module imports CSS and nothing matches styled classes for behaviour —
 * the DOM contract uses attributes and ids (Phase 6 §8.1).
 */
(() => {
  'use strict';

  // Guarded: matchMedia is absent in some environments (e.g. jsdom).
  const reduceMotion = () =>
    !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

  /* ------------------------------------------------------------------------
     1 · Active navigation — mark the current page, derived from the URL.
     Scoped to the two nav lists; the header CTA button and footer links are
     intentionally not candidates.
     ------------------------------------------------------------------------ */
  function initActiveNav() {
    const lists = document.querySelectorAll('.primary-nav__list, .mobile-nav__list');
    if (!lists.length) return;

    const currentKey = (location.pathname.split('/').filter(Boolean).pop() || '').replace(/\.html$/, '');

    const normalize = (href) => {
      const path = new URL(href, location.href).pathname;
      return (path.split('/').filter(Boolean).pop() || '').replace(/\.html$/, '');
    };

    lists.forEach((list) => {
      list.querySelectorAll('a[href]').forEach((link) => {
        const matches = currentKey !== '' && normalize(link.getAttribute('href')) === currentKey;
        if (matches) {
          link.setAttribute('aria-current', 'page');
        } else {
          link.removeAttribute('aria-current');
        }
      });
    });
  }

  /* ------------------------------------------------------------------------
     2 · Mobile navigation (Phase 5 §3.4) — open/close, focus management,
     Escape, link-click close, scroll lock, resize reset.
     ------------------------------------------------------------------------ */
  function initMobileNav() {
    const toggle = document.querySelector('[aria-controls="mobile-nav"]');
    const menu = document.getElementById('mobile-nav');
    if (!toggle || !menu) return;

    let lastFocus = null;

    const isOpen = () => menu.classList.contains('is-open');

    // Visibility is enforced by the browser on focus() — filter out
    // explicitly hidden / disabled items only (works everywhere, incl. jsdom).
    const getFocusable = () =>
      Array.from(menu.querySelectorAll('a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])'))
        .filter((el) => !el.hidden && el.getAttribute('aria-hidden') !== 'true');

    const lockScroll = (lock) => {
      document.documentElement.style.overflow = lock ? 'hidden' : '';
    };

    const openMenu = () => {
      if (isOpen()) return;
      lastFocus = document.activeElement;
      menu.classList.add('is-open');
      toggle.setAttribute('aria-expanded', 'true');
      toggle.setAttribute('aria-label', 'Close menu');
      lockScroll(true);
      const first = getFocusable()[0];
      if (first) first.focus();
    };

    const closeMenu = (restoreFocus = true) => {
      if (!isOpen()) return;
      menu.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('aria-label', 'Open menu');
      lockScroll(false);
      if (restoreFocus && lastFocus && typeof lastFocus.focus === 'function') {
        lastFocus.focus();
      }
    };

    const trapFocus = (event) => {
      const focusable = getFocusable();
      if (!focusable.length) {
        event.preventDefault();
        return;
      }
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };

    toggle.addEventListener('click', () => {
      if (isOpen()) closeMenu();
      else openMenu();
    });

    document.addEventListener('keydown', (event) => {
      if (!isOpen()) return;
      if (event.key === 'Escape') {
        closeMenu();
      } else if (event.key === 'Tab') {
        trapFocus(event);
      }
    });

    menu.addEventListener('click', (event) => {
      if (event.target.closest('a, button')) closeMenu(false);
    });

    window.addEventListener('resize', () => {
      if (window.matchMedia('(min-width: 1024px)').matches) closeMenu(false);
    }, { passive: true });
  }

  /* ------------------------------------------------------------------------
     3 · Smooth scrolling — internal anchor links only. Falls back to native
     behaviour when the target is missing or reduced motion is preferred.
     Offsets the sticky header so targets are never hidden beneath it.
     ------------------------------------------------------------------------ */
  function initSmoothScroll() {
    const header = document.querySelector('.site-header');

    document.addEventListener('click', (event) => {
      const link = event.target.closest('a[href^="#"]');
      if (!link) return;

      const href = link.getAttribute('href');
      if (!href || href.length < 2) return;

      const target = document.getElementById(href.slice(1));
      if (!target) return;

      event.preventDefault();

      let top = target.getBoundingClientRect().top + window.scrollY;
      if (header) top = Math.max(top - header.offsetHeight, 0);

      if (reduceMotion()) {
        window.scrollTo(0, top);
      } else {
        window.scrollTo({ top, behavior: 'smooth' });
      }

      if (event.detail === 0) {
        target.setAttribute('tabindex', '-1');
        target.focus({ preventScroll: true });
      }
    });
  }

  /* ------------------------------------------------------------------------
     4 · Header state — subtle raised shadow once scrolled (Phase 5 §3.1
     "scrolled" variant). Passive scroll listener, cached selector.
     ------------------------------------------------------------------------ */
  function initHeaderState() {
    const header = document.querySelector('.site-header');
    if (!header) return;

    const onScroll = () => {
      header.classList.toggle('is-scrolled', window.scrollY > 0);
    };

    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ------------------------------------------------------------------------
     5 · Form enhancement (Phase 5 §5.9 ValidationMessage · §5.10 FormStatus)
     Validation copy per Phase 3 §6.8. Inline messages reuse the existing
     .form-validation system; aria-invalid and aria-describedby keep the
     messages bound to their fields. While the form action is the
     FORMSPREE_ENDPOINT placeholder, a valid submission renders a success
     status and never leaves the page; once the placeholder is replaced with
     the live endpoint, valid forms submit natively (no JavaScript post).
     ------------------------------------------------------------------------ */
  const MESSAGES = {
    name: { required: 'Please enter your name.' },
    email: {
      required: 'Please enter your work email.',
      format: 'Enter a valid email address, e.g. name@company.in.',
    },
    phone: {
      required: 'Please enter your phone number.',
      format: 'Enter a 10-digit mobile number.',
    },
    service: { required: 'Please select a service.' },
    message: { required: 'Please tell us a little about the project.' },
  };

  const FALLBACK_REQUIRED = 'Please fill in this field.';
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const SUCCESS_MESSAGE =
    'Thank you. Your enquiry has been received. A senior engineer will contact you within two business hours.';

  const isValidPhone = (value) => {
    const digits = value.replace(/\D/g, '');
    return /^[6-9]\d{9}$/.test(digits) || /^91[6-9]\d{9}$/.test(digits);
  };

  const getMessageHost = (field) => {
    if (field.type === 'checkbox' || field.type === 'radio') return field.closest('.form-check');
    if (field.tagName === 'SELECT') return field.closest('.form-select');
    return field;
  };

  const addDescribedBy = (field, id) => {
    const current = field.getAttribute('aria-describedby');
    if (current && current.split(/\s+/).includes(id)) return;
    field.setAttribute('aria-describedby', current ? `${current} ${id}` : id);
  };

  const removeDescribedBy = (field, id) => {
    const current = field.getAttribute('aria-describedby');
    if (!current) return;
    const ids = current.split(/\s+/).filter((value) => value && value !== id);
    if (ids.length) field.setAttribute('aria-describedby', ids.join(' '));
    else field.removeAttribute('aria-describedby');
  };

  const clearError = (field) => {
    field.removeAttribute('aria-invalid');
    removeDescribedBy(field, `${(field.id || field.name)}-error`);
    const container = field.closest('.form-field');
    if (!container) return;
    const message = container.querySelector('.js-form-message');
    if (message) message.remove();
  };

  const renderError = (field, message) => {
    clearError(field);
    field.setAttribute('aria-invalid', 'true');

    const container = field.closest('.form-field');
    if (!container) return;

    const id = `${field.id || field.name}-error`;
    const messageEl = document.createElement('p');
    messageEl.className = 'form-validation form-validation--error js-form-message';
    messageEl.setAttribute('role', 'alert');
    messageEl.id = id;

    const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    icon.setAttribute('class', 'form-validation__icon');
    icon.setAttribute('aria-hidden', 'true');
    icon.setAttribute('viewBox', '0 0 24 24');
    icon.setAttribute('fill', 'none');
    icon.setAttribute('stroke', 'currentColor');
    icon.setAttribute('stroke-width', '1.5');
    icon.setAttribute('stroke-linecap', 'round');
    icon.setAttribute('stroke-linejoin', 'round');
    icon.innerHTML = '<path d="M12 9v4M12 17h.01M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>';

    const text = document.createElement('span');
    text.textContent = message;

    messageEl.appendChild(icon);
    messageEl.appendChild(text);

    const host = getMessageHost(field);
    host.parentNode.insertBefore(messageEl, host.nextSibling);
    addDescribedBy(field, id);
  };

  const fieldMessage = (field) => {
    const name = field.name;
    const config = MESSAGES[name] || {};

    if (field.type === 'checkbox' || field.type === 'radio') {
      return field.required && !field.checked ? (config.required || FALLBACK_REQUIRED) : '';
    }

    const raw = typeof field.value === 'string' ? field.value.trim() : '';

    if (field.required && raw === '') {
      return config.required || FALLBACK_REQUIRED;
    }

    if (raw !== '' && field.type === 'email' && !EMAIL_RE.test(raw)) {
      return config.format || '';
    }

    if (raw !== '' && (field.type === 'tel' || name === 'phone') && !isValidPhone(raw)) {
      return config.format || '';
    }

    return '';
  };

  const validateField = (field) => {
    const message = fieldMessage(field);
    if (message) renderError(field, message);
    else clearError(field);
    return !message;
  };

  const validateForm = (form) => {
    const fields = Array.from(form.querySelectorAll('input, select, textarea'));
    const invalid = [];
    fields.forEach((field) => {
      if (!validateField(field)) invalid.push(field);
    });
    return invalid;
  };

  const showFormStatus = (form, message) => {
    const previous = form.parentNode.querySelector('.js-form-status');
    if (previous) previous.remove();

    const status = document.createElement('p');
    status.className = 'form-validation form-validation--success js-form-status';
    status.setAttribute('role', 'status');
    status.setAttribute('tabindex', '-1');

    const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    icon.setAttribute('class', 'form-validation__icon');
    icon.setAttribute('aria-hidden', 'true');
    icon.setAttribute('viewBox', '0 0 24 24');
    icon.setAttribute('fill', 'none');
    icon.setAttribute('stroke', 'currentColor');
    icon.setAttribute('stroke-width', '1.5');
    icon.setAttribute('stroke-linecap', 'round');
    icon.setAttribute('stroke-linejoin', 'round');
    icon.innerHTML = '<path d="M20 6 9 17l-5-5"></path>';

    const text = document.createElement('span');
    text.textContent = message;

    status.appendChild(icon);
    status.appendChild(text);
    form.parentNode.insertBefore(status, form.nextSibling);
    status.focus();
  };

  const PLACEHOLDER_ACTION = 'FORMSPREE_ENDPOINT';

  function initFormValidation() {
    const form = document.querySelector('form[data-js="contact-form"]');
    if (!form) return;

    form.noValidate = true;

    form.addEventListener('submit', (event) => {
      const invalid = validateForm(form);
      if (invalid.length) {
        event.preventDefault();
        invalid[0].focus();
        return;
      }
      if (form.getAttribute('action') === PLACEHOLDER_ACTION) {
        event.preventDefault();
        showFormStatus(form, SUCCESS_MESSAGE);
      }
    });

    form.addEventListener('blur', (event) => {
      if (event.target.matches('input, select, textarea')) validateField(event.target);
    }, true);

    form.addEventListener('change', (event) => {
      if (event.target.matches('input, select, textarea')) validateField(event.target);
    });
  }

  /* ------------------------------------------------------------------------
     6 · Product image carousel — lightweight, dependency-free. Progressive
     enhancement only: without JS the first image and the dots/controls are
     visible but inert. One image per slide, manually driven (no autoplay).
     Touch uses pointer events with touch-action: pan-y so vertical page
     scrolling stays native while horizontal swipes slide the carousel; mouse
     drag works on desktop; Arrow Left/Right (and Home/End) navigate when the
     carousel has keyboard focus; the visible buttons and dots also work.
     ------------------------------------------------------------------------ */
  function initCarousels() {
    const carousels = document.querySelectorAll('[data-carousel]');

    carousels.forEach((carousel) => {
      const track = carousel.querySelector('[data-carousel-track]');
      const slides = Array.from(carousel.querySelectorAll('[data-carousel-slide]'));
      const dots = Array.from(carousel.querySelectorAll('[data-carousel-dot]'));
      const prev = carousel.querySelector('[data-carousel-prev]');
      const next = carousel.querySelector('[data-carousel-next]');
      const viewport = carousel.querySelector('[data-carousel-viewport]');
      const count = slides.length;

      if (!track || !viewport || count < 2) return;

      let index = 0;
      let pointerId = null;
      let startX = 0;
      let dragOffset = 0;
      let dragged = false;

      const baseTransform = (i) => `translateX(-${i * 100}%)`;

      function goTo(target) {
        index = (target + count) % count;
        track.style.transform = baseTransform(index);
        track.classList.remove('is-dragging');
        slides.forEach((slide, i) => {
          const active = i === index;
          slide.setAttribute('aria-hidden', String(!active));
          const img = slide.querySelector('img');
          if (img) img.setAttribute('loading', active ? 'eager' : 'lazy');
        });
        dots.forEach((dot, i) => {
          dot.classList.toggle('is-active', i === index);
          dot.setAttribute('aria-current', String(i === index));
        });
      }

      prev.addEventListener('click', () => goTo(index - 1));
      next.addEventListener('click', () => goTo(index + 1));
      dots.forEach((dot) => {
        dot.addEventListener('click', () => goTo(Number(dot.dataset.carouselIndex) || 0));
      });

      carousel.addEventListener('keydown', (event) => {
        if (event.key === 'ArrowLeft') {
          event.preventDefault();
          goTo(index - 1);
        } else if (event.key === 'ArrowRight') {
          event.preventDefault();
          goTo(index + 1);
        } else if (event.key === 'Home') {
          event.preventDefault();
          goTo(0);
        } else if (event.key === 'End') {
          event.preventDefault();
          goTo(count - 1);
        }
      });

      const threshold = Math.max(60, Math.round(viewport.clientWidth * 0.25));

      viewport.addEventListener('pointerdown', (event) => {
        pointerId = event.pointerId;
        startX = event.clientX;
        dragOffset = 0;
        dragged = false;
        try { viewport.setPointerCapture(pointerId); } catch (error) { /* ignore */ }
        track.classList.add('is-dragging');
      });

      viewport.addEventListener('pointermove', (event) => {
        if (event.pointerId !== pointerId) return;
        dragOffset = event.clientX - startX;
        if (Math.abs(dragOffset) > 4) dragged = true;
        const width = viewport.clientWidth || 1;
        const ratio = Math.max(-1, Math.min(1, dragOffset / width));
        track.style.transform = `translateX(calc(${-index * 100}% + ${ratio * 100}%))`;
      });

      function endDrag() {
        if (pointerId === null) return;
        pointerId = null;
        if (dragged) {
          goTo(dragOffset < 0 ? index + 1 : index - 1);
        } else {
          goTo(index);
        }
        dragged = false;
      }

      viewport.addEventListener('pointerup', endDrag);
      viewport.addEventListener('pointercancel', endDrag);

      goTo(0);
    });
  }

  /* ------------------------------------------------------------------------
     Boot — run once the DOM is ready (DOMContentLoaded). Deferred scripts
     execute at readyState "interactive" (before the event fires), so the
     listener is still registered in that case; only a fully complete
     document runs immediately.
     ------------------------------------------------------------------------ */
  const init = () => {
    initActiveNav();
    initMobileNav();
    initSmoothScroll();
    initHeaderState();
    initFormValidation();
    initCarousels();
  };

  if (document.readyState === 'complete') {
    init();
  } else {
    document.addEventListener('DOMContentLoaded', init);
  }
})();
